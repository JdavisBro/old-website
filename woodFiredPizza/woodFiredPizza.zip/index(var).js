var OEConfWEVideo = {"WE702c0b4d9e":{"ExportValues":"Flash player will function after <b>site is PUBLISHED</b><br />(<b><u>local videos</u></b> do not load in Flash)##ERROR: NO SUPPORTED VIDEO","Links":[{"Target":null,"Links":{"Items":{"DEFAULT":"Files/Video/woodFiredPizza.mp4"}}},null,null]}}
var OEConfWECollapsiblePanel = {"WEbcbcba9755":{"Delay":500,"EasingCloseJs":"easeOutQuad","EasingOpenJs":"none","EventType":0,"IsOpen":false,"PanelPosition":0}}
var OEConfEGbe9bcb73 = {"WE0ecec8f7c0":{"Startoffset":0,"Offsety":0,"Horizontalposition":0,"Verticalposition":0}}
var OEConfSharedEGbe9bcb73 = {"Text":{},"Images":{},"Files":{}}
